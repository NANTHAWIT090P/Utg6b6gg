Build:
1) เปิด https://fabricmc.net/develop เลือก 1.21.11 แล้วแก้ gradle.properties
   (yarn_mappings, loader_version, loom_version, fabric_version) ให้ตรง
2) ถ้าไม่มี gradlew ให้รัน: gradle wrapper (หรือคัดลอกจาก template ของ Fabric)
3) ./gradlew build -> jar ใน build/libs/ (ใช้ไฟล์ที่ไม่มี -sources)
4) วางลง mods พร้อม Fabric API (Fabric Loader 1.21.11, Java 21)

ค่าที่ปรับอยู่ใน FpsBoostClient.java แก้ตัวเลขได้ตามต้องการ
