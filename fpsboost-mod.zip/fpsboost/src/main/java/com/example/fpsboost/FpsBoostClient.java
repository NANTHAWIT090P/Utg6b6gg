package com.example.fpsboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;

/**
 * ปรับตั้งค่าที่กิน FPS ให้เบาลงตอนเปิดเกม (ทำครั้งเดียว) แล้วบันทึกลง options.txt
 * ผู้เล่นปรับกลับเองในเมนู Video Settings ได้ตามปกติ
 */
public class FpsBoostClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(this::apply);
    }

    private void apply(MinecraftClient client) {
        GameOptions o = client.options;

        o.getViewDistance().setValue(8);
        o.getSimulationDistance().setValue(8);
        o.getEntityDistanceScaling().setValue(0.75);
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getEntityShadows().setValue(false);
        o.getMaxFps().setValue(260);
        o.getEnableVsync().setValue(false);

        o.write();
    }
}
